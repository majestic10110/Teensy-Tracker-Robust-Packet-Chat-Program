Robust Chat — Support Files Bundle (with Debug Placeholders)
============================================================

Extract this ZIP into the SAME folder as your main Robust_Chat program.

Files
-----
- store/settings.json        ← MYCALL pre-filled with "M0OLI"
- store/link_graph.json      ← starter with "M0OLI" and empty heard map
- store/messages_v1.json     ← empty persistent message history
- store/gps_debug_last.txt   ← placeholder for GPS debug logs
- store/ack_debug.txt        ← placeholder for ACK debug logs
- store/relay_debug.txt      ← placeholder for relay debug logs
- fleetlist.json             ← root-level fleet configuration (Default fleet with M0OLI)
- VT323-Regular.ttf          ← placeholder font (replace with real TTF)

Notes
-----
• These debug files are empty placeholders; the program will write to them as needed.
• The main program (.py) is NOT included in this ZIP.
