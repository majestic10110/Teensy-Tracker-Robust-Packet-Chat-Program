Robust Chat Default Bundle
==========================

Root (place next to your .py launcher):
- settings.json      -> app configuration (COM port, baud, theme, etc.)
- Fleetlist.json     -> fleet manager groups

store\ (leave folder name lowercase):
- link_graph.json    -> placeholder for link map data
- fixed_gps.json     -> used by the SEND GPS button
- messages_v1.json   -> message store (array). App will append here.

Defaults set to COM4 @ 9600. Change settings.json if you use a different port.
Bundle created: 2025-09-25T10:59:51.908297Z
